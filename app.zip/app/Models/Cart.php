<?php


/**
 * summary
 * Jean Lionel
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    /**
     * summary
     */
    public function __construct()
    {

    }
}
